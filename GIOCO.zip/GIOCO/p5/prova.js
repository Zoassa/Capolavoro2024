function controllaCellaPremuta() {
    if(!this.indovinato) { //controlla prima se la cella è già stata indovinata, così almeno non deve ogni volta controllare che io
        //prema sopra alla cella con il mouse, ma semplicemente se la cella è già stata indovinata la "ignora"
        //console.log("furi"+mousePremuto);
        if (mouseIsPressed && mousePremuto === false) {
            // console.log("dentro"+mousePremuto);
            mousePremuto = true;
            var d = dist(mouseX, mouseY, this.posX + (this.dimX / 2), this.posY + (this.dimY / 2)); //calcola la distanza tra la posizione del mouse e la posizione inserita (400, 400)
            if (d < 25) {
                if (this.valoreCella == 0) {
                    if(numeroSelezionato ==  this.valoreGiusto) {
                        this.valoreCella = numeroSelezionato;
                        this.indovinato = true;
                    } else {
                        numeroErrori ++;

                    }
                }
            }
        } else {
            mousePremuto = false;
        }
    }
}