 class Cella {
     static imgCellaPremuta; //= loadImage("images/cellaRosa.png");
     static imgCellaNonPremuta; //= loadImage("images/cellaBianca.png");
     static dimensioneCarattere = 40;
     //idCella --> x scorrere la lista dei valori --> ad ogni cella assegno un numero
     //valoreGiusto --> numero giusto da mettere nella cella, cioè la soluzione
     constructor(posX, posY, dimX, dimY, valoreCella, valoreGiusto, idCella) {

        this.posX = posX;
        this.posY = posY;
        this.dimX = dimX;
        this.dimY = dimY;
        this.valoreCella = valoreCella;
        this.indovinato = false;
        textSize(Cella.dimensioneCarattere);
        this.valoreGiusto = valoreGiusto;
        this.idCella = idCella;
    }

    drawCella() {
        textSize(45);
        if(!this.indovinato) {
            image(Cella.imgCellaNonPremuta, this.posX, this.posY, this.dimX, this.dimY);
            fill("black"); //colore testo
            if(this.valoreCella == 0) {
                text("-", (this.posX + this.dimX/2) - Cella.dimensioneCarattere/2, (this.posY + this.dimY/2) + Cella.dimensioneCarattere/4);
            } else {
                text(this.valoreCella, (this.posX + this.dimX/2) - Cella.dimensioneCarattere/2, (this.posY + this.dimY/2) + Cella.dimensioneCarattere/4);
            }

        }else {
            image(Cella.imgCellaPremuta, this.posX, this.posY, this.dimX, this.dimY);
            fill("black");
            text(this.valoreCella, (this.posX + this.dimX/2) - Cella.dimensioneCarattere/2, (this.posY + this.dimY/2) + Cella.dimensioneCarattere/4);

        }

    }
     controllaCellaPremuta() {
         if(this.indovinato === false) { //controlla prima se la cella è già stata indovinata, così almeno non deve ogni volta controllare che io
             //prema sopra alla cella con il mouse, ma semplicemente se la cella è già stata indovinata la "ignora"
             //console.log("furi"+mousePremuto);
             //console.log("posizioni" + this.posX, this.posY)
             if (mouseIsPressed) {
                 if(mousePremuto == false) {
                     //console.log("dentro" + mousePremuto);
                     var d = dist(mouseX, mouseY, this.posX + (this.dimX / 2), this.posY + (this.dimY / 2)); //calcola la distanza tra la posizione del mouse e la posizione inserita (400, 400)
                     //console.log("distanza, musex, musey, posx,pooosy"+d,mouseX, mouseY, this.posX + (this.dimX / 2), this.posY + (this.dimY / 2));
                     if (d < 25) {
                         mousePremuto = true;
                         if (this.valoreCella == 0) {
                             if (numeroSelezionato == this.valoreGiusto) {
                                 this.valoreCella = numeroSelezionato;
                                 this.indovinato = true;
                                 indovinati ++;
                             } else {
                                 //console.log("errori aumenta bitches");
                                 numeroErrori ++;

                             }
                         }
                     }
                 }
             } else {
                 mousePremuto = false;
             }

         }
     }
}

