let schermata = 1;
let img; //<-- errore devi lasciare l'inizializzazione 

function preload() {
    img = loadImage("scrittaIniziale.jpeg");
}


function setup() {
  preload();
  createCanvas(1520, 690);
  background(img);
  //stroke(226,204,0);
}

function show() {
  image(img, 0, 0, 1520, 690);
}

function setup() {
  createCanvas(400, 400);
  //Crea un pulsante per aprire il secondo file
  let button = createButton('Apri il secondo file');
  button.mousePressed(openSeconFile);
}

function openSeconFile() {
  window.location.href = 'gioco.html'; //ok si c'è qualcosa che non va qui 
}

function draw() {
  if (schermata === 1) {
    // Disegna la schermata 1
    /*background(220);
    textSize(32);
    textAlign(CENTER, CENTER);
    text('Schermata 1', width/2, height/2);*/
    background(img);
    //image(picIniziale, 0, 0);
  } else if (schermata === 2) {
    // Disegna la schermata 2
    background(120);
    textSize(32);
    textAlign(CENTER, CENTER);
    text('Schermata 2', width/2, height/2);
  }
}

function keyPressed() {
  if (keyCode === ENTER) {
    // Passa alla schermata successiva quando si preme INVIO
    schermata ++;
    if (schermata > 2) {
      schermata = 1;
    }
  }
}
