
/*
ok l'unica cosa e che facendo così dovrei rifare il draw e il setup tutte le volte 
la cosa che ti consiglio e di utilizzare lo stesso file e cambiare il file solo per le diverse classi 
e controllare nel draw cosa vuoi disegnare e cosa no aspe che modifico solo una robetta che mi sono dimenticato 

tu comunque vuoi passare da una schermata all'altra no ? +
si ma senza aprire nuove schede 
ok allora secodno me ti conviene fare cosi... posso modificare fortemente il codice?
si ma scrivimi cosa fanno le cose sennò non capisco poi 
si si vai tra allora aspe 

*/
/*
var numeroSelezionato = null;
var righe;
var colonne;

var errori = 0;

scheda var = [
    "--74916-5",
    "2---6-3-9",
    "-----7-1-",
    "-586----4",
    "--3----9-",
    "--62--187",
    "9-4-7---2",
    "67-83----",
    "81--45---"
]



var soluzioni = [
    "387491625",
    "241568379",
    "569327418",
    "758619234",
    "123784596",
    "496253187",
    "934176852",
    "675832941",
    "812945763"
]

window.onload = function() {
    gioco();
}

function gioco() {
    for (let i = 1; i <= 9; i++) {

        let n = document.createElement("div");
        n.id = i
        n.innerText = i;
        n.addEventListener("click", selectNumber);
        n.classList.add("numero");
        document.getElementById("numeriInBasso").appendChild(n);
    }

    for (righe = 0; righe < 9; righe ++) {
        for (colonne = 0; colonne < 9; colonne ++) {
            let cella = document.createElement("div");
            cella.id = righe.toString() + "-" + colonne.toString();
            if (tabellaIniziale[righe][colonne] != "-") {
                cella.innerText = tabellaIniziale[righe][colonne];
                cella.classList.add("cellePredefinite");
            }
            if (righe == 2 || righe == 5) {
                cella.classList.add("orizzontale");
            }
            if (colonne == 2 || colonne == 5) {
                cella.classList.add("verticale");
            }
            cella.addEventListener("click", selezionaCella);
            cella.classList.add("cella");
            document.getElementById("board").append(cella);
        }
    }
}


function selectNumber(){
    if (numeroSelezionato != null) {
        numeroSelezionato.classList.remove("coloreNumSelezionato");
    }
    numeroSelezionato = this;
    numeroSelezionato.classList.add("coloreNumSelezionato");
}


function selezionaCella() {
    if (numeroSelezionato) {
        if (this.innerText != "") {
            return;
        }

        let dividi = this.id.split("-");
        let righe = parseInt(dividi[0]);
        let colonne = parseInt(dividi[1]);

        if (soluzioni[righe][colonne] == numeroSelezionato.id) {
            this.innerText = numeroSelezionato.id;
        }
        else {
            errori += 1;
            document.getElementById("numero").innerText = errori;
        }
    }
}

*/



let titoloIniziale; // <-- salvo l'immagine iniziale
let verticale = 600;
let orizzontale = 1400;
let qualeSchermata = 0; //dice in quale schermata sono
let pulsanteStart;
let sfondoGioco;
let bottoneHome;
let dimCella = 50;
let griglia = [];
let valoriCelleCorretti = [3,8,7,4,9,1,6,2,5,2,4,1,5,6,8,3,7,9,5,6,9,3,2,7,4,1,8,7,5,8,6,1,9,2,3,4,1,2,3,7,8,4,5,9,6,4,9,6,2,5,3,1,8,7,9,3,4,1,7,6,8,5,2,6,7,5,8,3,2,9,4,1,8,1,2,9,4,5,7,6,3];
let valoriCelleMostrati = [0,0,7,4,9,1,6,0,5,2,0,0,0,6,0,3,0,9,0,0,0,0,0,7,0,1,0,0,5,8,6,0,0,0,0,4,0,0,3,0,0,0,0,9,0,0,0,6,2,0,0,1,8,7,9,0,4,0,7,0,0,0,2,6,7,0,8,3,0,0,0,0,8,1,0,0,4,5,0,0,0];
let bottoneInfo;
let bottoneIndietro;
let numeroSelezionato;
let debug = true;
let numeroErrori = 0;
let sfondoInfo;
let val;
let mousePremuto = false;
let bottonePausa;
let prosegui;
let restart;
let vinto;
let perso;
let numeriIndovinare = 46;
let indovinati = 0;

//funzione per il caricamento delle immagini
function preload(){
    titoloIniziale = loadImage("images/scrittaIniziale.png");
    pulsanteStart = loadImage("images/pulsanteStart.png");
    sfondoGioco = loadImage("images/sfondoGioco.png");
    bottoneHome = loadImage("images/immagineBottoneHome.png");
    bottoneInfo = loadImage("images/immagineBottoneInfo.png");
    bottoneIndietro = loadImage("images/pulsanteIndietro.png");
    sfondoInfo = loadImage("images/sfondoInfo.png");
    bottonePausa = loadImage("images/tastoPausa.png");
    prosegui = loadImage("images/tastoProseguiGioco.png");
    restart = loadImage("images/tastoRestart.png");
    vinto = loadImage("images/vittoria.png");
    perso = loadImage("images/sconfitta.png");
}

function setup(){
    createCanvas(orizzontale,verticale);

    Cella.imgCellaPremuta = loadImage("images/cellaRosa.png");
    Cella.imgCellaNonPremuta = loadImage("images/cellaBianca.png");
    inizializzaCelle();
}

function drawSchermataPrincipale(){
    image(titoloIniziale, 0, 0, orizzontale, verticale);
    image(pulsanteStart, orizzontale/2 - (150/2), verticale/2 - (70/2), 150, 70);
    controlloMouse(1, orizzontale/2 - (150/2), verticale/2 - (70/2), 150, 70);
    delay(10000);
}

function schermataGioco() {
    image(sfondoGioco, 0, 0, orizzontale, verticale);
    image(bottoneHome, 25, verticale-70, 50, 50);
    image(bottoneInfo, orizzontale-70, 20, 50, 50);
    image(bottonePausa, orizzontale-150, 20, 50, 50);
    controlloMouse(0, 10, 530, 50, 50);
    controlloMouse(2, orizzontale-70, 20, 50, 50);
    controlloMouse(3, orizzontale-150, 20, 50, 50);
    stampaCelle();
    controlloTastiera();
    controllaCelle();
    fill("black");
    textSize(20);
    text("Errori effettuati: \n", orizzontale - 350, 150);
    textSize(40);
    text(numeroErrori + "/4", orizzontale - 330, 200)
    console.log("errori: "+numeroErrori);
    if(numeroErrori == 4) {
        delay(20000);
        schermataSconfitta();
    } else if(indovinati == numeriIndovinare){
        schermataVittoria();
    }
}

function schermataInfo() {
    image(sfondoInfo, 0, 0, orizzontale, verticale);
    image(bottoneHome, 25, verticale-70, 50, 50);
    image(bottoneIndietro, 100, verticale-70, 50, 50);
    controlloMouse(0, 25, verticale-70, 50, 50);
    controlloMouse(1, 100, verticale-70, 50, 50);
}

function schermataPausa() {
    background("black");
    image(prosegui, orizzontale/2 -(100/2) + 90, verticale/2 - (100/2), 100, 100);
    image(restart, orizzontale/2 -(100/2) - 90, verticale/2 - (100/2), 100, 100);
    controlloMouse(1, orizzontale/2 -(100/2) + 90, verticale/2 - (100/2), 100, 100);
    controlloMouse(0, orizzontale/2 -(100/2) - 90, verticale/2 - (100/2), 100, 100);
}

function schermataVittoria() {
    image(vinto, 0, 0, orizzontale, verticale);
    fill("blue");
    textSize(30);
    text("Premi qui per ricominciare: ", orizzontale - 450, verticale - 35);
    image(restart, orizzontale - 70, verticale - 70, 50, 50);
    controlloMouse(0, orizzontale - 70, verticale - 70, 50, 50);
}

function schermataSconfitta() {
    image(perso, 0, 0, orizzontale, verticale);
    fill("cyan");
    textSize(30);
    text("Premi qui per ricominciare: ", orizzontale - 450, verticale - 35);
    image(restart, orizzontale - 70, verticale - 70, 50, 50);
    controlloMouse(0, orizzontale - 70, verticale - 70, 50, 50);
}

function controlloMouse(raggiungiSchermata, pulsX, pulsY, dimX, dimY) {
    if (mouseIsPressed) {
        delay(10000);
        //mouseX, mouseY
        //pulsX e pulsY = ANGOLO IN ALTO A SINISTRA
        var d = dist(mouseX, mouseY, pulsX + (dimX / 2), pulsY + (dimY / 2)); //calcola la distanza tra la posizione del mouse e la posizione inserita (400, 400)
        if (d < 50) {
            qualeSchermata = raggiungiSchermata;
            if (qualeSchermata == 0) {
                location.reload();
            }
        }

    }

}

function inizializzaCelle() {
    var k, j;
    var xIniziale =  orizzontale/2 - dimCella*9/2;
    var yIniziale = verticale/2 - dimCella*9/2;
    var id = 0;
    //k = verticale/2 - dimCella*9/2 --> per centrarla nell'altezza del canvas
    //praticamente io sto creando l'insieme di tutte le celle, cioè parto da un punto e gli sommo le dimensioni delle celle
    for(k = 0; k < 9; k ++) {
        console.log("k="+k);
        for(j = 0; j < 9; j ++) {
            console.log("j="+j);
            //viene inserita una nuova cella
            if(j == 3 || j == 6){
                xIniziale = xIniziale + 5;
            }
            griglia.push(new Cella(xIniziale + j*dimCella, yIniziale + k*dimCella, dimCella, dimCella, valoriCelleMostrati[id], valoriCelleCorretti[id], id));
            id ++;
        }
        xIniziale = xIniziale -10;
        if(k == 2|| k == 5){
            yIniziale = yIniziale +5; //domani cheidere questo ad Andrea
        }


    }
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function stampaCelle() {
    var k; 
    for(k = 0; k < griglia.length; k ++) {
        griglia[k].drawCella();
    }
}

function draw(){
    
    if(qualeSchermata == 0) {
        drawSchermataPrincipale();
    } else if (qualeSchermata == 1) {
        schermataGioco();
    } else if(qualeSchermata == 2) {
        schermataInfo();
    } else if(qualeSchermata == 3) {
        schermataPausa();
    }

}

function controlloTastiera () {
    //key <-- viene creato una sorta di buffer in cui vengono salvati
    //tutti gli input da tastiera
    if (key >= 1 && key <= 9) {
        fill("orange");
        textSize(40);
        text("Numero selezionato: \n", 30, 150);
        textSize(250);
        text(key, 100, 360); //stringa da stampare, posizioni in cui stamparlo
        numeroSelezionato = key;
        if(debug) {
            console.log(numeroSelezionato); //mi stampa in console il numero che ho selezioanto (serve per gli errori) (per far in modo che non stampi più niente in console, basta che la metto a false)
        }

    } else {
        fill("red");
        textSize(30);
        text("NESSUN NUMERO\nSELEZIONATO \n", 30, 150);
    }
}

function controllaCelle() {
    var k;
    for(k = 0; k < griglia.length; k ++) {
        griglia[k].controllaCellaPremuta();
       // console.log("distanza premuto" + k, griglia[k].posX);
    }
}


